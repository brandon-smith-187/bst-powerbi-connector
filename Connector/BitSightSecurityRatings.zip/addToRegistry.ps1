﻿$outputErr = ""
$registryPath = "HKLM:\SOFTWARE\Policies\Microsoft"
$registryItemPath = "HKLM:\SOFTWARE\Policies\Microsoft\Power BI Desktop"
$registryItemName = "Power BI Desktop"
$registryValueName = "TrustedCertificateThumbprints"
$thumbPrint = "962D5518323DF1F146A88C3283D6A6B3072BD5FB"
$MyError = ""

$testRegistryPath = Test-Path -Path "$registryItemPath" -ErrorAction SilentlyContinue -ErrorVariable MyError

function Add-Connector-ItemProperty {

    param (
        $ItemPath,
        $ValueName,
        $thumbprint
    )

    $newValueCommand = New-ItemProperty -Path "$registryItemPath" -Name "$registryValueName" -PropertyType MultiString -Value @"
$thumbPrint
"@ -ErrorAction SilentlyContinue -ErrorVariable MyError

    if($newValueCommand) 
    {
        Write-Host "Connector thumbprint added successfuly. Finishing..."
    }
    else
    {
        Write-Host "Error adding value to the registry. Finishing..."
        throw $MyError
    }

}

if(!$testRegistryPath)
{
    Write-Host "Registry item path does not exist. Creating..."

    $newRegistryItem = New-Item -Path "$registryPath" -Name "$registryItemName" -ErrorAction SilentlyContinue -ErrorVariable MyError

    if($newRegistryItem) 
    {
        Write-Host "New registry item added successfuly. Continuing..."
    }
    else
    {
        Write-Error "Error adding item to the registry. Finishing..."
        Write-Error $MyError
        pause
    }

    Write-Host "Registry item value does not exist. Creating..."

    $newValueCommand = Add-Connector-ItemProperty -ItemPath "$registryItemPath" -ValueName "$registryValueName" -thumbprint $thumbPrint

}
else
{
    Write-Host "Registry path exists. Checking for connector thumbprint property..."

    $propertyExists = Get-ItemProperty -Path "$registryItemPath" -Name $registryValueName -ErrorAction SilentlyContinue -ErrorVariable MyError

    if(!$propertyExists) 
    {
        Write-Host "Property does not exist. Adding Thumbprint property to the registry..."
        $newValueCommand = Add-Connector-ItemProperty -ItemPath "$registryItemPath" -ValueName $registryValueName -thumbprint $thumbPrint
    } 
    else 
    {
        Write-Host "Property exists. Adding new thumbprint value to the registry property..."
    
        $propertyValue = Get-ItemProperty -Path "$registryItemPath" -Name $registryValueName -ErrorAction SilentlyContinue -ErrorVariable MyError

        if(!$propertyValue) 
        {
            Write-Host "Error obtaining the registry value."
            throw $MyError
        }

        $editedValue = $propertyValue.$registryValueName + $thumbPrint

        $setValue = Set-ItemProperty -Path "$registryItemPath" -Name $registryValueName -Value $editedValue -ErrorAction SilentlyContinue -ErrorVariable MyError

        if(!$propertyValue) 
        {
            Write-Host "Error editing the registry value."
            throw $MyError
        }
        else
        {
            Write-Host "New connector thumbprint added successfuly."
        }
    }
}

