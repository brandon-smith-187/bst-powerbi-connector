﻿$MyError = ""
$powerBIConnectorRelativePath = "\Power BI Desktop\Custom Connectors"
$documentsPath = [Environment]::GetFolderPath("MyDocuments")
$powerBIDesktopAbsolutePath =  "$documentsPath\Power BI Desktop"
$powerBIConnectorsAbsolutePath = $documentsPath + $powerBIConnectorRelativePath
$scriptPath = Split-Path $MyInvocation.MyCommand.Path -Parent

function copy-connector {
	try
	{
		Copy-Item "$scriptPath\BitSightSecurityRatings.pqx" -Destination "$powerBIConnectorsAbsolutePath" -ErrorAction Stop
		Write-Host "Connector copied"
	}
	catch
	{
		$Host.UI.WriteErrorLine("Errors occured. Check stderr.txt for details.")
        Write-Host $Error[0]
	}
}

function pause{ $null = Read-Host 'Process finished. Press Enter to exit...' }

#Write-Host $powerBIConnectorsAbsolutePath

$powerBIDirExists = Test-Path -Path "$powerBIDesktopAbsolutePath" -ErrorAction SilentlyContinue -ErrorVariable MyError

$customConnectorsDirExists = Test-Path -Path "$powerBIConnectorsAbsolutePath" -ErrorAction SilentlyContinue -ErrorVariable MyError

if($powerBIDirExists) #Does Power BI directory exists in Documents?
{
    Write-Host "Directory Power BI Desktop exists in Documents. Checking for the Custom Connectors dir..."
} 
else 
{
    Write-Host "Power BI Desktop directory does not exist in Documents. Creating..."
	try
	{
		New-Item -Path "$documentsPath" -Name "Power BI Desktop" -ItemType "directory" -ErrorAction Stop
		Write-Host "Power BI Desktop directory created in Documents. Creating Custom Connectors directory..."
		New-Item -Path "$powerBIDesktopAbsolutePath" -Name "Custom Connectors" -ItemType "directory" -ErrorAction Stop
		Write-Host "Custom Connectors directory created in Documents. Copying Connector file..."
		copy-connector
		pause
		exit
	}
	catch
	{
		$Host.UI.WriteErrorLine("Errors occured. Check stderr.txt for details.")
        Write-Host $Error[0]
	}
}

if($customConnectorsDirExists) 
{
    Write-Host "Directory Custom Connectors exists in Power BI Desktop. Copying Connector file..."
    copy-connector
}
else
{
    Write-Host "Directory Custom Connectors does not exist in Power BI Desktop. Creating..."
	New-Item -Path "$powerBIDesktopAbsolutePath" -Name "Custom Connectors" -ItemType "directory" -ErrorAction Stop
	Write-Host "Custom Connectors directory created in Documents. Copying Connector file..."
	copy-connector
	pause
}