$MyError = ""
$MyOutput = ""
$scriptPath = Split-Path $MyInvocation.MyCommand.Path -Parent

function pause{ $null = Read-Host 'Process finished. Press Enter to exit...' }

try
{
    Start-Process -NoNewWindow -RedirectStandardOutput "$scriptPath\stdout.txt" -RedirectStandardError "$scriptPath\stderr.txt" -FilePath "powershell" -ArgumentList "-noprofile -file ""$scriptPath\addToRegistry.ps1""" -ErrorAction Stop -ErrorVariable MyError
    Write-Host "Connector thumbprint added successfuly to the Windows Registry."
	Start-Process -NoNewWindow -RedirectStandardOutput "$scriptPath\stdout.txt" -RedirectStandardError "$scriptPath\stderr.txt" -FilePath "powershell" -ArgumentList "-noprofile -file ""$scriptPath\copyFile.ps1""" -ErrorAction Stop -ErrorVariable MyError
	Write-Host "Connector copied to the Custom Connectors folder."
	Write-Host "All done!"
    pause
}
catch
{
    $Host.UI.WriteErrorLine("Errors occured. Check stderr.txt for details.")
    throw $Error[0]
}

